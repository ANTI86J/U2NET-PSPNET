from torch.utils.data import Dataset
import os
from torchvision import transforms
import img_process as ig
import cv2
from PIL import Image


data_dir = 'D:\Downloads\diaretdb1_v_1_1\\resources\images\ddb1_fundusimages'
label_hemorrhages_data = 'D:\Downloads\diaretdb1_v_1_1\\resources\images\ddb1_groundtruth\hemorrhages'
label_soft_data = 'D:\Downloads\diaretdb1_v_1_1\\resources\images\ddb1_groundtruth\softexudates'
label_rsd_data = 'D:\Downloads\diaretdb1_v_1_1\\resources/images\ddb1_groundtruth\\redsmalldots'
label_hard_data = 'D:\Downloads\diaretdb1_v_1_1\\resources\images\ddb1_groundtruth\hardexudates'
data_txt = 'D:\Downloads\diaretdb1_v_1_1\\resources\\traindatasets\\trainset.txt'


def extract(file_dir):
    with open(file_dir, 'r') as f1:
        li = f1.readlines()
    for i in range(len(li)):
        li[i] = li[i].rstrip('\n')
    return li


class MyDataset(Dataset):
    def __init__(self):
        super(MyDataset, self).__init__()
        self.dataset = extract(data_txt)
        self.dataset = self.dataset

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, index):
        try:
            image = Image.open(os.path.join(data_dir, self.dataset[index]))
            image = ig.guassian(image)
            # image.show()
            # image = ig.color_enhancement(image)
            # img2 = ig.bright_enhancement(image)
            # img3 = ig.shape_enhancement(img2)
            # img3 = ig.noist_erase(img3)
            # print(index, '1')

            label = Image.open(os.path.join(label_hard_data, self.dataset[index]))
            # print(self.dataset[index], '2')
            # label.show()
            label = ig.grey_process(label)
            # label.show()
            pad = max(image.size)
            size = (pad, pad)
            transform = transforms.Compose([
                transforms.CenterCrop(size=size),
                transforms.Resize(256),
                transforms.ToTensor(),
            ])
            image_data = transform(image)
            label_data = transform(label)
            return image_data, label_data
        except IOError:
            print("Can't find the file")
        else:
            return self.__getitem__(index + 1)

