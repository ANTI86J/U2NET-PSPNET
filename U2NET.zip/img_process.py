import cv2
from PIL import ImageEnhance
import numpy as np
from PIL import Image


def guassian(image):
    # 高斯滤波降噪处理

    # 判断是否为cv2可处理类型图像，否则PIL转
    if not isinstance(image, np.ndarray):
        image = cv2.cvtColor(np.asarray(image), cv2.COLOR_RGB2BGR)
    img = cv2.GaussianBlur(image, (5, 5), 0)
    img2 = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    return img2


def grey_process(image):
    if type(image) is np.ndarray:
        image = Image.fromarray(image)
    img_grey = image.convert('L')
    threshold = 192
    table = []
    for i in range(256):
        if i >= threshold:
            table.append(1)
        else:
            table.append(0)
    img_final = img_grey.point(table, '1')
    return img_final


def bright_enhancement(image):
    # 亮度增强

    img_bri = ImageEnhance.Brightness(image)
    brightness = 1.5
    image_brightened = img_bri.enhance(brightness)
    # image_brightened.show()
    return image_brightened


def contrast_enhancement(image):
    # 对比度增强

    img_con = ImageEnhance.Contrast(image)
    contrast = 1.5
    img_contrast = img_con.enhance(contrast)
    # img_contrast.show()
    return img_contrast


def shape_enhancement(image):
    # 锐度增强

    img_sha = ImageEnhance.Sharpness(image)
    sharpness = 1.5
    img_sharp = img_sha.enhance(sharpness)
    # img_sharp.show()
    return img_sharp


def color_enhancement(image):
    # 色彩增强

    img_col = ImageEnhance.Color(image)
    color = 1.5
    img_color = img_col.enhance(color)
    # img_color.show()
    return img_color


def noist_erase(img):
    dst = cv2.fastNlMeansDenoisingColored(img, None, 10, 10, 7, 21)
    return dst

