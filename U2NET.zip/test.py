import torch
from u2net import U2NET
from DataLoader import extract
import os
from PIL import Image
from torchvision import transforms
import time
import cv2
import random
import img_process as ig
import numpy as np
import torch.nn as nn
from UNet import U_net


file_txt = 'D:\Downloads\diaretdb1_v_1_1\\resources\\traindatasets\\trainset.txt'
data_dir = 'D:\Downloads\diaretdb1_v_1_1\\resources\images\ddb1_fundusimages'
label_hard_data = 'D:\Downloads\diaretdb1_v_1_1\\resources\images\ddb1_groundtruth\hardexudates'


def accuracy(out, label):
    label, out = ig.grey_process(label), ig.grey_process(out)
    out_np, label_np = np.asarray(out), np.asarray(label)
    if not out_np.shape == label_np.shape:
        print('False')
    h, w = out_np.shape
    acc, total = 0, 0
    for i in range(h):
        for j in range(w):
            if out_np[i, j] == label_np[i, j]:
                acc = acc+1
            total = total + 1
    return float(acc/total)


def to_numpy(item):
    '''
    convert input to numpy array
    input type: image-file-name, PIL image, torch tensor, numpy array
    '''
    if 'str' in str(type(item)):  # read the image as numpy array
        item = np.array(Image.open(item))
    elif 'PIL' in str(type(item)):
        item = np.array(item)
    elif 'torch' in str(type(item)):
        item = item.cpu().numpy()
    elif 'numpy' in str(type(item)):
        pass
    else:  # unsupported type
        print('WTF:', str(type(item)))
        return None
    return item


def dice_coeff(pred, lable):
    # convert to numpy array
    pred = to_numpy(pred)
    lable = to_numpy(lable)

    # convert to 1-D array for convinience
    pred = pred.flatten()
    lable = lable.flatten()
    # convert to 0-1 array
    # up = np.unique(pred)
    # ul = np.unique(lable)
    # print(up, ul)
    pred = np.uint8(pred == 1)
    lable = np.uint8(lable == 1)

    met_dict = {}  # metrics dictionary

    TP = np.count_nonzero((pred + lable) == 2)  # true positive
    print('TP: ', TP)
    TN = np.count_nonzero((pred + lable) == 0)  # true negative
    print('TN: ', TN)
    FP = np.count_nonzero(pred > lable)  # false positive
    print('FP: ', FP)
    FN = np.count_nonzero(pred < lable)  # false negative
    print('FN: ', FN)

    # AUC = roc_auc_score(lable, pred)
    smooth = 1e-9  # avoid devide zero
    acc = (TP + TN) / (TP + TN + FP + FN + smooth)  # accuracy
    pre = TP / (TP + FP + smooth)  # sensitivity, or precision
    sp = TN / (TN + FP + smooth)  # specificity
    rc = TP / (TP + FN + smooth)  # recall
    f1 = 2 * pre * rc / (pre + rc + smooth)  # F1 mesure
    jac = TP / (TP + FP + FN + smooth)  # jaccard coefficient

    # return metrics as dictionary
    met_dict['TP'] = TP
    met_dict['TN'] = TN
    met_dict['FP'] = FP
    met_dict['FN'] = FN
    met_dict['acc'] = acc
    met_dict['pre'] = pre
    met_dict['sp'] = sp
    met_dict['rc'] = rc
    met_dict['f1'] = f1
    met_dict['jac'] = jac
    # met_dict['AUC'] = AUC
    return met_dict


if __name__ == '__main__':
    epoch, e = 0, 0
    loss_total = 0.0
    jac = 0.0
    acc = 0.0
    f1_total, f_epoch = 0.0, 0
    sn_total, sen_epoch = 0.0, 0
    sp_total, sp_epoch = 0.0, 0
    rc_total, r_epoch = 0.0, 0
    net = U2NET()
    # net = U_net()
    net.cuda()
    # net.load_state_dict(torch.load('UNET.pt'))
    net.load_state_dict(torch.load('U2NET-PSPNET.pt'))
    # net.load_state_dict(torch.load('neteyes.pt'))
    net.eval()
    loss_function = nn.BCELoss(reduction='mean')
    li = extract(file_dir=file_txt)
    for address in li:
        address = os.path.join(data_dir, address)
    random.shuffle(li)
    for dir in li:
        with torch.no_grad():
            e += 1
            image = Image.open(os.path.join(data_dir, dir)).convert('RGB')
            image = ig.guassian(image)
            label = Image.open(os.path.join(label_hard_data, dir))
            label = ig.grey_process(label)
            label1 = label
            print(dir)
            # image.show()
            pad = max(image.size)
            size = (pad, pad)
            transform = transforms.Compose([
                transforms.CenterCrop(size),
                transforms.Resize(256),
                transforms.ToTensor()
            ])
            data = transform(image)
            data = torch.unsqueeze(data, 0)
            label = transform(label)
            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            label = label.to(device)
            data = data.to(device)
            label = torch.unsqueeze(label, 0)

            start = time.time()
            out0, out1, out2, out3, out4, out5, out6 = net(data)
            # out0 = net(data)
            loss = loss_function(out0, label)
            dice = dice_coeff(out0, label)
            if dice['TN'] != 65536:
                epoch = epoch + 1

                print('time: ', time.time() - start)
                print('loss: ', loss)

                print('jac: ', dice['jac'])
                print('f1: ', dice['f1'])
                print('sensitivity: ', dice['pre'])
                print('specificity: ', dice['sp'])
                print('recall: ', dice['rc'], '\n')
                jac += dice['jac']
                f1_total += dice['f1']
                sn_total += dice['pre']
                sp_total += dice['sp']
                rc_total += dice['rc']
                loss_total += loss
                acc += dice['acc']
            print('acc: ', dice['acc'])

            sum = out0 + label
            o0 = out0.view(256, 256).cpu().detach().numpy()
            # label1.show()
            # cv2.imshow('o0', o0)
            # cv2.waitKey(0)

    print('average loss: ', loss_total / epoch)
    print('average jac: ', jac/epoch)
    print('average f1: ', f1_total/epoch)
    print('average precision: ', sn_total / epoch)
    print('average specificity: ', sp_total / epoch)
    print('average recall: ', rc_total/epoch)
    print('average acc: ', acc/epoch)