import torch
from torch import nn
import torch.nn.functional as F


class ConvBlock(nn.Module):
    # 封装每一层所需要的操作

    def __init__(self, in_ch=3, out_ch=3, dirate=1):
        # Conv + BN + relu
        super(ConvBlock, self).__init__()
        self.conv = nn.Conv2d(in_ch, out_ch, 3, padding=dirate, dilation=dirate)
        self.bn = nn.BatchNorm2d(out_ch)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        # 操作封装
        return self.relu(self.bn(self.conv(x)))


def Upsample(src, tar):
    # 对图像进行上采样操作
    return F.interpolate(src, size=tar.shape[2:], mode='bilinear')


class Encode(nn.Module):
    # 定义每一个编码层
    def __init__(self, in_channels, out_channels, dirate):
        super(Encode, self).__init__()
        # ConvBlock操作 + 最大池化
        self.conv = ConvBlock(in_channels, out_channels, dirate)
        self.pool = nn.MaxPool2d(2, 2, ceil_mode=True)

    def forward(self, x):
        # 封装操作
        return self.pool(self.conv(x))


class RSU1(nn.Module):
    # 第一层
    def __init__(self, in_ch=3, mid_ch=12, out_ch=3):
        super(RSU1, self).__init__()
        self.en1 = ConvBlock(in_ch, out_ch, dirate=1)
        self.en2 = Encode(out_ch, mid_ch, 1)
        self.en3 = Encode(mid_ch, mid_ch, 1)
        self.en4 = Encode(mid_ch, mid_ch, 1)
        self.en5 = Encode(mid_ch, mid_ch, 1)
        self.en6 = Encode(mid_ch, mid_ch, 1)
        self.en7 = ConvBlock(mid_ch, mid_ch, 2)
        self.en8 = ConvBlock(mid_ch, mid_ch, 2)

        # 涉及左边和右边对应层的拼接，所以in_ch size * 2
        self.de6 = ConvBlock(mid_ch * 2, mid_ch, dirate=1)
        self.de5 = ConvBlock(mid_ch * 2, mid_ch, dirate=1)
        self.de4 = ConvBlock(mid_ch * 2, mid_ch, dirate=1)
        self.de3 = ConvBlock(mid_ch * 2, mid_ch, dirate=1)
        self.de2 = ConvBlock(mid_ch * 2, mid_ch, dirate=1)
        self.de1 = ConvBlock(mid_ch * 2, out_ch, dirate=1)

    def forward(self, x):
        en1 = self.en1(x)
        en2 = self.en2(en1)
        en3 = self.en3(en2)
        en4 = self.en4(en3)
        en5 = self.en5(en4)
        en6 = self.en6(en5)
        en7 = self.en7(en6)
        en8 = self.en8(en7)

        # 对应层拼接
        de6 = self.de6(torch.cat([en8, en7], dim=1))
        de5 = self.de5(torch.cat([de6, en6], dim=1))
        de5 = Upsample(de5, en5)
        de4 = self.de4(torch.cat([de5, en5], dim=1))
        de4 = Upsample(de4, en4)
        de3 = self.de3(torch.cat([de4, en4], dim=1))
        de3 = Upsample(de3, en3)
        de2 = self.de2(torch.cat([de3, en3], dim=1))
        de2 = Upsample(de2, en2)
        de1 = self.de1(torch.cat([de2, en2], dim=1))
        de1 = Upsample(de1, en1)
        return de1 + en1


class RSU2(nn.Module):
    def __init__(self, in_ch=3, middle_ch=12, out_ch=3):
        super(RSU2, self).__init__()
        self.en1 = ConvBlock(in_ch, out_ch, dirate=1)
        self.en2 = Encode(out_ch, middle_ch, 1)
        self.en3 = Encode(middle_ch, middle_ch, 1)
        self.en4 = Encode(middle_ch, middle_ch, 1)
        self.en5 = Encode(middle_ch, middle_ch, 1)
        self.en6 = ConvBlock(middle_ch, middle_ch)
        self.en7 = ConvBlock(middle_ch, middle_ch, dirate=2)

        self.de5 = ConvBlock(middle_ch * 2, middle_ch)
        self.de4 = ConvBlock(middle_ch * 2, middle_ch)
        self.de3 = ConvBlock(middle_ch * 2, middle_ch)
        self.de2 = ConvBlock(middle_ch * 2, middle_ch)
        self.de1 = ConvBlock(middle_ch * 2, out_ch)

    def forward(self, x):
        en1 = self.en1(x)
        en2 = self.en2(en1)
        en3 = self.en3(en2)
        en4 = self.en4(en3)
        en5 = self.en5(en4)
        en6 = self.en6(en5)
        en7 = self.en7(en6)

        de5 = self.de5(torch.cat([en7, en6], dim=1))
        de4 = self.de4(torch.cat([de5, en5], dim=1))
        de4 = Upsample(de4, en4)
        de3 = self.de3(torch.cat([de4, en4], dim=1))
        de3 = Upsample(de3, en3)
        de2 = self.de2(torch.cat([de3, en3], dim=1))
        de2 = Upsample(de2, en2)
        de1 = self.de1(torch.cat([de2, en2], dim=1))
        de1 = Upsample(de1, en1)
        return de1 + en1


class RSU3(nn.Module):
    def __init__(self, in_ch=3, middle_ch=12, out_ch=3):
        super(RSU3, self).__init__()
        self.en1 = ConvBlock(in_ch, out_ch)
        self.en2 = Encode(out_ch, middle_ch, 1)
        self.en3 = Encode(middle_ch, middle_ch, 1)
        self.en4 = Encode(middle_ch, middle_ch, 1)
        self.en5 = ConvBlock(middle_ch, middle_ch)
        self.en6 = ConvBlock(middle_ch, middle_ch, dirate=2)

        self.de4 = ConvBlock(middle_ch * 2, middle_ch)
        self.de3 = ConvBlock(middle_ch * 2, middle_ch)
        self.de2 = ConvBlock(middle_ch * 2, middle_ch)
        self.de1 = ConvBlock(middle_ch * 2, out_ch)

    def forward(self, x):
        en1 = self.en1(x)
        en2 = self.en2(en1)
        en3 = self.en3(en2)
        en4 = self.en4(en3)
        en5 = self.en5(en4)
        en6 = self.en6(en5)

        de4 = self.de4(torch.cat([en6, en5], dim=1))
        de3 = self.de3(torch.cat([de4, en4], dim=1))
        de3 = Upsample(de3, en3)
        de2 = self.de2(torch.cat([de3, en3], dim=1))
        de2 = Upsample(de2, en2)
        de1 = self.de1(torch.cat([de2, en2], dim=1))
        de1 = Upsample(de1, en1)
        return de1 + en1


class RSU4(nn.Module):
    def __init__(self, in_ch=3, mid_ch=12, out_ch=3):
        super(RSU4, self).__init__()
        self.en1 = ConvBlock(in_ch, out_ch)
        self.en2 = Encode(out_ch, mid_ch, 1)
        self.en3 = Encode(mid_ch, mid_ch, 1)
        self.en4 = ConvBlock(mid_ch, mid_ch)
        self.en5 = ConvBlock(mid_ch, mid_ch, 2)

        self.de3 = ConvBlock(mid_ch * 2, mid_ch)
        self.de2 = ConvBlock(mid_ch * 2, mid_ch)
        self.de1 = ConvBlock(mid_ch * 2, out_ch)

    def forward(self, x):
        en1 = self.en1(x)
        en2 = self.en2(en1)
        en3 = self.en3(en2)
        en4 = self.en4(en3)
        en5 = self.en5(en4)

        de3 = self.de3(torch.cat([en5, en4], dim=1))
        de2 = self.de2(torch.cat([de3, en3], dim=1))
        de2 = Upsample(de2, en2)
        de1 = self.de1(torch.cat([de2, en2], dim=1))
        de1 = Upsample(de1, en1)
        return de1 + en1


class RSU5(nn.Module):
    def __init__(self, in_ch=3, mid_ch=12, out_ch=3):
        super(RSU5, self).__init__()
        self.en1 = ConvBlock(in_ch, out_ch)
        self.en2 = ConvBlock(out_ch, mid_ch)
        self.en3 = ConvBloc k(mid_ch, mid_ch, dirate=2)
        self.en4 = ConvBlock(mid_ch, mid_ch, dirate=4)
        self.en5 = ConvBlock(mid_ch, mid_ch, dirate=8)

        self.de3 = ConvBlock(mid_ch * 2, mid_ch, dirate=4)
        self.de2 = ConvBlock(mid_ch * 2, mid_ch, dirate=2)
        self.de1 = ConvBlock(mid_ch * 2, out_ch)

    def forward(self, x):
        en1 = self.en1(x)
        en2 = self.en2(en1)
        en3 = self.en3(en2)
        en4 = self.en4(en3)

        de3 = self.de3(torch.cat([en4, en3], dim=1))
        de2 = self.de2(torch.cat([de3, en3], dim=1))
        de1 = self.de1(torch.cat([de2, en2], dim=1))

        return de1 + en1


class PSPModule(nn.Module):
    # 第六层
    # 定义PSPNET中金字塔结构

    # 卷积核大小定义为1, 2, 4, 8, 16
    def __init__(self, in_ch, out_ch, mid_chs=(1, 2, 4, 8, 16)):
        super().__init__()
        self.stages = []
        self.stages = nn.ModuleList([self._make_stage(in_ch, ch) for ch in mid_chs])
        self.bottleneck = nn.Conv2d(in_ch * (len(mid_chs) + 1), out_ch, kernel_size=1)
        self.relu = nn.ReLU()

    def _make_stage(self, in_ch, ch):
        # 封装每一个卷积核内所做的操作
        prior = nn.AdaptiveAvgPool2d(output_size=(ch, ch))
        conv = nn.Conv2d(in_ch, in_ch, kernel_size=1, bias=False)
        # 将操作按顺序封装
        return nn.Sequential(prior, conv)

    def forward(self, x):
        h, w = x.size(2), x.size(3)
        prior = [F.interpolate(input=stage(x), size=(h, w), mode='bilinear', align_corners=True) for stage in self.stages] + [x]
        bottle = self.bottleneck(torch.cat(prior, 1))
        return self.relu(bottle)


class U2NET(nn.Module):
    # 定义封装整个网络层
    def __init__(self, in_ch=3, out_ch=1):
        super(U2NET, self).__init__()
        self.EN1 = nn.Sequential(RSU1(in_ch, 32, 64), nn.MaxPool2d(2, 2, ceil_mode=True))
        self.EN2 = nn.Sequential(RSU2(64, 32, 128), nn.MaxPool2d(2, 2, ceil_mode=True))
        self.EN3 = nn.Sequential(RSU3(128, 64, 256), nn.MaxPool2d(2, 2, ceil_mode=True))
        self.EN4 = nn.Sequential(RSU4(256, 128, 512), nn.MaxPool2d(2, 2, ceil_mode=True))
        self.EN5 = nn.Sequential(RSU5(512, 256, 512), nn.MaxPool2d(2, 2, ceil_mode=True))
        self.EN6 = PSPModule(512, 512)
        # self.EN6 = RSU5(512, 256, 512)

        self.De_5 = RSU5(1024, 256, 512)
        self.De_4 = RSU4(1024, 128, 256)
        self.De_3 = RSU3(512, 64, 128)
        self.De_2 = RSU2(256, 32, 64)
        self.De_1 = RSU1(128, 16, 64)

        self.side1 = nn.Conv2d(64, out_ch, 3, padding=1)
        self.side2 = nn.Conv2d(64, out_ch, 3, padding=1)
        self.side3 = nn.Conv2d(128, out_ch, 3, padding=1)
        self.side4 = nn.Conv2d(256, out_ch, 3, padding=1)
        self.side5 = nn.Conv2d(512, out_ch, 3, padding=1)
        self.side6 = nn.Conv2d(512, out_ch, 3, padding=1)

        self.sup0 = nn.Conv2d(6, 1, 1)

    def forward(self, x):
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        x = x.to(device)
        en1 = self.EN1(x)
        en2 = self.EN2(en1)
        en3 = self.EN3(en2)
        en4 = self.EN4(en3)
        en5 = self.EN5(en4)
        en6 = self.EN6(en5)

        de5 = self.De_5(torch.cat([en6, en5], dim=1))
        de5 = Upsample(de5, en4)
        de4 = self.De_4(torch.cat([de5, en4], dim=1))
        de4 = Upsample(de4, en3)
        de3 = self.De_3(torch.cat([de4, en3], dim=1))
        de3 = Upsample(de3, en2)
        de2 = self.De_2(torch.cat([de3, en2], dim=1))
        de2 = Upsample(de2, en1)
        de1 = self.De_1(torch.cat([de2, en1], dim=1))
        # 恢复到原来的shape
        de1 = Upsample(de1, x)

        side1 = self.side1(Upsample(de1, x))
        side2 = self.side2(Upsample(de2, x))
        side3 = self.side3(Upsample(de3, x))
        side4 = self.side4(Upsample(de4, x))
        side5 = self.side5(Upsample(de5, x))
        side6 = self.side6(Upsample(en6, x))
        # 将六层结果拼接,并卷积
        sup0 = self.sup0(torch.cat([side1, side2, side3, side4, side5, side6], dim=1))
        return torch.sigmoid(sup0), torch.sigmoid(side1), torch.sigmoid(side2), torch.sigmoid(side3), torch.sigmoid(side4), torch.sigmoid(side5), torch.sigmoid(side6)